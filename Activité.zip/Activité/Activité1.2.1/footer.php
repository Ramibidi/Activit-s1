<div style="background-color : green ;clear:both;">
© Copyright - Contact -  Mention legales </div>