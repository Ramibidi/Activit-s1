<html>
    <div style="display:flex;justify-content:space-around;margin-top:50px;">
<?php 

echo "<a href=\"utils.php\"> Articles</a></br></br>";
echo "<a href=\"last3.php\"> last articles</a>";
?>
</div>
</html>