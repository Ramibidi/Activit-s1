<html>
<head>
<div style="background-color : green ;clear:both;">
            <ul style="display:flex; justify-content : space-evenly;">
            <a href="Article1.php">Article1</a>
            <a href="Article2.php">Article2</a>
            <a href="Article3.php">Article3</a>
                
            </ul>
        </div>
<body>


</body>
</html>