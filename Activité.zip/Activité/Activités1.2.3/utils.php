<?php function getArticles($nombre_article){

$articles = [

    [

        'titre' => 'Article 1',

        'texte' => 'Php',

        'auteur' => 'Youssef',

        'date' => '16-10-2021',

        

    ],

    [

        'titre' => 'Article 2',

        'texte' => 'Java',

        'auteur' => 'Mohamed',

        'date' => '19-02-2021',

    ],

    [

        'titre' => 'Article 3',

        'texte' => 'Fahed',

        'auteur' => 'Nawers',

        'date' => '03-01-2021',

    ],
    [

        'titre' => 'Article 4',

        'texte' => 'Web',

        'auteur' => 'Rami',

        'date' => '15-02-2021',

    ],
    [

        'titre' => 'Article 5',

        'texte' => 'Ceci est le 5ème article',

        'auteur' => 'ali',

        'date' => '05-04-2021',

    ],

];




// Compare function
function date_compare($element1, $element2) {
    $datetime1 = strtotime($element1['date']);
    $datetime2 = strtotime($element2['date']);
    return $datetime2 - $datetime1;
}
    // Sort the array 
    $sort=usort($articles, 'date_compare');


    if ($nombre_article>0 && $nombre_article<5)

    {
          $sliced_array[] = array_slice($articles, 0, $nombre_article);
        //   echo "few";

      return print_r($sliced_array);

    }

    else if ($nombre_article>=6)  {
        foreach ($articles as $subarray) {

            $finalArray[] = $subarray;
    }
    print_r($finalArray);
    // echo "all";
}
}

//function to get the last 3 items

getArticles(6);

?>